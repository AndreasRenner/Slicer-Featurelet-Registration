
""" This module loads all the classes from the vtkSlicerRegistrationModuleLogic library into its
namespace."""

from vtkSlicerRegistrationModuleLogicPython import *
