
""" This module loads all the classes from the vtkSlicerRegistrationModuleMRML library into its
namespace."""

from vtkSlicerRegistrationModuleMRMLPython import *
